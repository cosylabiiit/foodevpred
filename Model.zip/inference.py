"""
Food EV Classifier — Inference Script (GPU Optimized)
=====================================================
Input  : raw protein sequence (string)
Output : predicted class + class probabilities

Pipeline:
  sequence -> ProtT5-XL embedding (fp16 on GPU, mean-pooled)
           -> select RFE 256 dims
           -> StandardScaler
           -> 3 base models (LR, SVM, MLP)
           -> XGBoost meta-model 
           -> LabelEncoder translation

Run load_artifacts() + load_prott5() once at server startup.
"""

import os, json
import numpy as np
import joblib
import torch

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
PACKAGE_DIR = r"C:\Users\shind\Desktop\1web_package\ml_delivery_package"   
MAX_SEQ_LEN = 1024                    
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ─────────────────────────────────────────────────────────────────────────────
# 1. LOAD ARTIFACTS
# ─────────────────────────────────────────────────────────────────────────────
_artifacts = {}

def load_artifacts(package_dir: str = PACKAGE_DIR):
    with open(os.path.join(package_dir, "rfe_256_features.json")) as f:
        rfe_meta = json.load(f)

    with open(os.path.join(package_dir, "meta_feature_layout.json")) as f:
        layout = json.load(f)

    _artifacts["dim_indices"]   = rfe_meta["dim_indices"]          
    _artifacts["scaler"]        = joblib.load(os.path.join(package_dir, "scaler.pkl"))
    _artifacts["base_models"]   = joblib.load(os.path.join(package_dir, "base_models.pkl"))
    _artifacts["meta_model"]    = joblib.load(os.path.join(package_dir, "meta_model.pkl"))
    _artifacts["label_encoder"] = joblib.load(os.path.join(package_dir, "label_encoder.pkl"))
    _artifacts["model_order"]   = layout["base_model_order"]       

    print(f"[OK] Artifacts loaded. Model order: {_artifacts['model_order']}, "
          f"classes: {list(_artifacts['label_encoder'].classes_)}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. LOAD PROTT5 (GPU / FP16)
# ─────────────────────────────────────────────────────────────────────────────
_prott5 = {}

def load_prott5():
    from transformers import T5Tokenizer, T5EncoderModel

    print(f"Loading ProtT5-XL on {DEVICE}...")
    tok = T5Tokenizer.from_pretrained("Rostlab/prot_t5_xl_uniref50", do_lower_case=False)
    
    # Loaded in fp16 to save ~6GB of VRAM and dramatically speed up inference!
    mdl = T5EncoderModel.from_pretrained(
        "Rostlab/prot_t5_xl_uniref50", torch_dtype=torch.float16
    ).eval().to(DEVICE)

    _prott5["tok"] = tok
    _prott5["mdl"] = mdl
    print(f"[OK] ProtT5-XL loaded successfully in fp16.")


def _clean_sequence(seq: str) -> str:
    seq = seq.strip().upper()
    seq = seq.replace("U", "X").replace("Z", "X").replace("O", "X").replace("B", "X")
    return seq[:MAX_SEQ_LEN]


def embed_sequence(seq: str) -> np.ndarray:
    tok, mdl = _prott5["tok"], _prott5["mdl"]

    cleaned = _clean_sequence(seq)
    spaced  = " ".join(list(cleaned))

    enc = tok([spaced], return_tensors="pt", padding=True,
               truncation=True, max_length=MAX_SEQ_LEN + 1).to(DEVICE)

    with torch.no_grad():
        out = mdl(**enc)

    # Cast back to float32 before sending to CPU for Scikit-Learn
    hidden = out.last_hidden_state.float()                 
    mask   = enc["attention_mask"].unsqueeze(-1).float()    
    emb    = (hidden * mask).sum(1) / mask.sum(1)             

    return emb.cpu().numpy()[0]   


# ─────────────────────────────────────────────────────────────────────────────
# 3. VALIDATION
# ─────────────────────────────────────────────────────────────────────────────
VALID_AA = set("ACDEFGHIKLMNPQRSTVWYXUZOB")

def validate_sequence(seq: str) -> str:
    if not seq or not seq.strip():
        raise ValueError("Empty sequence.")
    cleaned = seq.strip().upper()
    bad_chars = set(cleaned) - VALID_AA
    if bad_chars:
        raise ValueError(f"Invalid characters in sequence: {sorted(bad_chars)}")
    if len(cleaned) < 5:
        raise ValueError("Sequence too short (minimum 5 residues).")
    return cleaned


# ─────────────────────────────────────────────────────────────────────────────
# 4. PREDICT
# ─────────────────────────────────────────────────────────────────────────────
def predict(seq: str) -> dict:
    seq = validate_sequence(seq)

    # 1. Embed -> 1024-dim
    emb_1024 = embed_sequence(seq)

    # 2. Select RFE 256 dims
    emb_256 = emb_1024[_artifacts["dim_indices"]].reshape(1, -1)

    # 3. Scale
    emb_scaled = _artifacts["scaler"].transform(emb_256)

    # 4. Base model probabilities
    base_models = _artifacts["base_models"]
    model_order = _artifacts["model_order"]
    meta_feature = np.concatenate(
        [base_models[name].predict_proba(emb_scaled) for name in model_order],
        axis=1
    )  

    # 5. Meta model prediction
    meta_clf = _artifacts["meta_model"]
    pred_idx = int(meta_clf.predict(meta_feature)[0])
    pred_proba = meta_clf.predict_proba(meta_feature)[0]

    # 6. Translate to your specific labels
    LABEL_MAP = {
        0: "Non-EV",
        1: "Milk-based EV",
        2: "Plant-based EV"
    }
    pred_label = LABEL_MAP[pred_idx]

    return {
        "predicted_class": pred_label,
        "predicted_index": pred_idx,
        "probabilities": {LABEL_MAP[i]: float(p) for i, p in enumerate(pred_proba)}
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. TEST EXECUTION
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    load_artifacts()
    load_prott5()

    example_seq = "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSG"
    
    print("\nRunning test inference...")
    result = predict(example_seq)
    print(json.dumps(result, indent=2))